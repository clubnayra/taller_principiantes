//
//  SingelPoleFilter.cpp
//  
//
//  Created by Dale Heatherington on 2/7/16.
//
//

#include "SinglePoleFilter.h"
#include <Arduino.h>

/* Fixed point math macros from ARM application note 33 */

/* convert a from q1 format to q2 format */
#define FCONV(a, q1, q2) (((q2)>(q1)) ? (a)<<((q2)-(q1)) : (a)>>((q1)-(q2)))


/* The basic operations perfomed on two numbers a and b of fixed
 point q format returning the answer in q format */
#define FADD(a,b) ((a)+(b))
#define FSUB(a,b) ((a)-(b))
#define FMUL(a,b,q) (((a)*(b))>>(q))
#define FDIV(a,b,q) (((a)<<(q))/(b))


/* The basic operations where a is of fixed point q format and b is
 an integer */
#define FADDI(a,b,q) ((a)+((b)<<(q)))
#define FSUBI(a,b,q) ((a)-((b)<<(q)))
#define FMULI(a,b) ((a)*(b))
#define FDIVI(a,b) ((a)/(b))

/* the general operation between a in q1 format and b in q2 format
 returning the result in q3 format */
#define FADDG(a,b,q1,q2,q3) (FCONV(a,q1,q3)+FCONV(b,q2,q3))
#define FSUBG(a,b,q1,q2,q3) (FCONV(a,q1,q3)-FCONV(b,q2,q3))
#define FMULG(a,b,q1,q2,q3) FCONV((a)*(b), (q1)+(q2), q3)
#define FDIVG(a,b,q1,q2,q3) (FCONV(a, q1, (q2)+(q3))/(b))

/* convert to and from floating point */
#define TOFIX(d, q) ((int)( (d)*(double)(1<<(q)) ))
#define TOFLT(a, q) ( (double)(a) / (double)(1<<(q)) )




//------------------------------------------------------------
/* Create filter instance
    Input parameters:
            type:  SinglePoleFilter::LOWPASS or SinglePoleFilter::HIGHPASS
            f0:     3db cutoff frequency
            fc:     Sample rate frequency
 
 */

SinglePoleFilter::SinglePoleFilter(filterType type, double f0,double fs)
{
    computeCoefficients(type,f0,fs);     //Calculate the coefficients
    
    z1 = 0;
  
    // Convert floating point to q14 fixed point

    b1 = TOFIX(bb1,q);
    a0 = TOFIX(aa0,q);
    
    fsp = 1000000/fs;   //Sample rate period in microseconds.

}

//------------------------------------------------------------------

/* This is the code that does the actual filtering.
 * input:  sampled signal data, 32 bit int.
 * returns filterd signal data
 * This must be called at the sample rate frequency, fs.
 *
 *
 */

int32_t SinglePoleFilter::filter(int32_t in)
{
    z1 = (in * a0 + z1 * b1) >> q;
    return z1;
}

//----------------------------------------------------------------------

void SinglePoleFilter::computeCoefficients(SinglePoleFilter::filterType type, double f0, double fs)
{
    if(type == LOWPASS){
    bb1 = exp(-2.0 * M_PI * (f0/fs));
    aa0 = 1.0 - bb1;
    }
    
    if(type == HIGHPASS){
        bb1 = -exp(-2.0 * M_PI * (0.5 - (f0/fs)));
        aa0 = 1.0 + bb1;
    }
    
}

//---------------------------------------------------------------------------

/* Returns sample rate period in microseconds for use with micros() timer */

uint32_t SinglePoleFilter::samplePeriod()
{
    
    return fsp;
}

//------------------------------------------------------------------------------







