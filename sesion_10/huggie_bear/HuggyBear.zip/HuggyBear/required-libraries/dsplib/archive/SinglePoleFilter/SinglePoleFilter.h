//
//  SingelPoleFilter.h
//  
//
//  Created by Dale Heatherington on 2/7/16.
//
//

#ifndef SinglePoleFilter_h
#define SinglePoleFilter_h
#include <stdint.h>

class SinglePoleFilter
{
    public:
    enum filterType{LOWPASS,HIGHPASS};
    
    SinglePoleFilter(SinglePoleFilter::filterType,double,double); //Constructor
    void computeCoefficients(SinglePoleFilter::filterType, double, double); //Coefficient calculator

    int32_t filter(int32_t);        //Do the actual filtering. Returns filtered sample.
    uint32_t samplePeriod();        //Return sample rate fs period in microseconds

    private:
    int32_t a0,b1,z1;
    double aa0,bb1;
    const int32_t q = 14;   // q for fixed point math is 14
    uint32_t fsp;   //Sample rate period in microseconds = 1000000/sample rate
};

#endif