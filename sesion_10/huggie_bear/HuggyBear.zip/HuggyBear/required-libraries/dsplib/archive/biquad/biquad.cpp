/* 
 *  Second order biquad direct form 1 filter library
 *
 *
 *
 *  Created by Dale Heatherington on Jan 24, 2016.
 *  This Code is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.
 *  This source code is provided as is, without warranty.
 *  You may copy and distribute verbatim copies of this document.
 *  You may modify and use this source code to create binary code
 *  for your own purposes, free or commercial.

*/

#include <Arduino.h>
#include "biquad.h"


//-----------------------------------------------------------------------
/* Create a filter instance
 
   Input parameters:
        type:   Biquad::LOWPASS or Biquad::HIGHPASS or Biquad::BANDPASS or Biquad::NOTCH
        f0:     3db cut off frequency for low and high pass. Center frequency for bandpass and notch.
        fs:     Sample rate frequency, typically 4x or more times f0.
        Q:      For low and high pass it is 0.7071.  For bandpass and notch it's f0 / 3db bandwidth.
 */

Biquad::Biquad( filterType type, double f0, double fs, double Q)
{
  
 computeCoefficients(type,f0,fs,Q);     //Calculate the coefficients
 
 x1 = 0;            //Zero the memorys
 x2 = 0;
 y1 = 0;
 y2 = 0;
    
    fsp = 1000000/fs;   //Sample rate period in microseconds.
 


//Convert floating point coefficients to 32 bit ints multiplied by 10000.
 // b1 = int32_t(bb1 * scale) ;
 // b2 = int32_t(bb2 * scale);;
 // a0 = int32_t(aa0 * scale);
 // a1 = int32_t(aa1 * scale);
 // a2 = int32_t(aa2 * scale);
 
// Convert floating point to q14 fixed point
    b1 = TOFIX(bb1,q);
    b2 = TOFIX(bb2,q);
    a0 = TOFIX(aa0,q);
    a1 = TOFIX(aa1,q);
    a2 = TOFIX(aa2,q);
    
  
}
//-----------------------------------------------------------------------
/* This is the code that does the actual filtering.
 * input:  sampled signal data, 32 bit int.
 * returns filterd signal data
 * This must be called at the sample rate frequency, fs.
 *
 *
 */
 

int32_t Biquad::filter(int32_t in){

   // int32_t y0 =  (  (in*a0) + (x1*a1) + (x2*a2) - (y1*b1) - (y2*b2) ) / scale;
    
    in = FCONV(in,0,q);     //Convert integer input to q14 fixed point
    
    int32_t y0 = (in*a0) + (x1*a1) + (x2*a2) - (y1*b1) - (y2*b2);
    
   x2 = x1;
   x1 = in;

   y2 = y1;
   y1 = y0;

   return FCONV(y0,q,0);  //Convert output from fixed point to integer
}

//--------------------------------------------------------------------------

/* Compute the coefficients
 * This code is based on information at:  http://www.musicdsp.org/files/Audio-EQ-Cookbook.txt
 * and also http://www.earlevel.com/main/2012/11/26/biquad-c-source-code/
 */

void Biquad::computeCoefficients(filterType type, double f0, double fs, double Q)
{
   double b0;
   double w0 = 2*PI*(f0/fs);
   double cosw0 = cos(w0);
   double sinw0 = sin(w0);
   double alpha = sinw0 / (2*Q);

   if(type == LOWPASS){

    b0 = 1 + alpha;
    bb1 = -2*cosw0/b0;
    bb2 = (1 - alpha) / b0;
    
    aa0 = ((1 - cosw0) / 2)/b0;
    aa1 = (1 - cosw0) / b0 ;
    aa2 = ((1 - cosw0) / 2) / b0;
    
    
   }

   if(type == HIGHPASS){
     b0 = 1 + alpha;
    bb1 = -2*cosw0/b0;
    bb2 = (1 - alpha) /b0;

    aa0 = ((1 + cosw0) / 2)/b0;
    aa1 = -(1 + cosw0) / b0 ;
    aa2 = ((1 + cosw0) / 2) / b0;
   }

   if(type == BANDPASS){
     b0 = 1 + alpha;
    bb1 = -2*cosw0/b0;
    bb2 = (1 - alpha) /b0;

    aa0 =   alpha / b0;
    aa1 =   0 ;
    aa2 =  -alpha / b0;
   }

  if(type == NOTCH){
     b0 = 1 + alpha;
    bb1 = -2*cosw0/b0;
    bb2 = (1 - alpha) / b0;

    aa0 =   1 / b0;
    aa1 =   (-2 * cosw0) / b0;
    aa2 =  1 / b0;
   }
   
   
   
  
}
//---------------------------------------------------------------------------

/* Returns sample rate period in microseconds for use with micros() timer */

uint32_t Biquad::samplePeriod()
{
    
    return fsp;
}

//--------------------------------------------------------------------------
/* print the scaled coefficients for debug */

void Biquad::print()
{
   Serial.print(b1);
   Serial.print(" ");
   Serial.print(b2);
   Serial.print(" ");
   Serial.print(a0);
   Serial.print(" ");
   Serial.print(a1);
   Serial.print(" ");
   Serial.print(a2);
   Serial.println(" ");
   
}


