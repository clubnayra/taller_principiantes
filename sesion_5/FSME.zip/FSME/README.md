# FSME

Finite State Machine for Embedded systems

A C++ library implementing a finite state machine model used on embedded systems, based on: http://www.ace.tuiasi.ro/users/103/Bind4.pdf
